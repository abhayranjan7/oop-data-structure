#include<stdio.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};
struct node *put(struct node *root,int k)
{
    if(root==NULL)
    {
        struct node *temp=(struct node *)malloc(sizeof(struct node));
        temp->data=k;
        temp->left=NULL;
        temp->right=NULL;
        root=temp;
    }
    else if(root->data>k)
    {
        root->left=put(root->left,k);
    }
    else{

        root->right=put(root->right,k);
    }
    return root;
}
int lca(struct node *root,int k,int count)
{
    int l,r, flag;
    if(root==NULL)
    {
        return 0;

    }
    if(root->data==k)
    {

            return count;
    }
    /*if(lca(root->left,k)||lca(root->right,k))
    {
        printf("%d ",root->data);
        return 1;
    }
    return 0;*/
     l=lca(root->left,k,count+1);
     r=lca(root->right,k,count+1);
 /*   if(l>r)
    {
        return l+1;
    }
    else{
        return r+1;
    }*/

}
int main()
{
    struct node *root=NULL;
    int count=0;
    root=put(root,9);
    put(root,8);
    put(root,14);
    put(root,17);
    put(root,1);
    put(root,6);
    put(root,5);
    put(root,12);
    put(root,4);
    put(root,18);
    int res=lca(root,4,count);
    printf("%d",res);
    return 0;
}
