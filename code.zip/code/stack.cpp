#include<iostream>
#include<stdlib.h>
#define max 100
using namespace std;
class stack
{
             int a[max];
             int top=-1;
      public:
             void push(int x)
              {
                 if(top >  max)
                       {
                           cout <<"stack overflow";
                           return;
                       }
                 a[++top]=x;
                 cout <<"done " <<x;
               }
             void pop()
               {
                  if(top <0)
                   {
                         cout <<"stack underflow";
                         return;
                    }
                    cout <<"done " <<a[top--];
                }
             void display()
               {
                   if(top<0)
                    {
                            cout <<" stack empty";
                            return;
                    }
                    for(int i=top;i>=0;i--)
                    cout <<a[i] <<" ";
                }
             void isempty()
             {
                 if(top==-1)
                 {
                     cout<<"yes\n";
                 }
                 else
                 {
                     cout<<"no\n";
                 }
             }
};

int main()
{
     int c,n;
     stack st;
     while(1)
        {
             cout <<"\n1.push  2.pop  3.display  4.isempty  5.exit\n";
             cin >> c;
             switch(c)
              {
               case 1:  cout <<"enter the element";
                        cin >> n;
                        st.push(n);
                        break;
               case 2:  st.pop();  break;
               case 3:  st.display();break;
               case 4:  st.isempty();
                        break;
               case 5:  exit(0);
               }
         }
return 0;
}
