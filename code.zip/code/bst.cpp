#include<iostream>
#include<stdlib.h>
using namespace std;
struct node
{
  int info;
  struct node *left;
  struct node *right;
};
class tree
{
  int num;
  node *root=NULL;
  node *p,*prev,*temp;
  public:
    void insert()
    {
        p=new(node);
        cout<<"Enter no\n";
        cin>>num;
        p->info=num;
        p->left=p->right=NULL;
        if(root==NULL)
        {
            root=p;
            return;
        }
        temp=root;
        while(temp!=NULL)
        {
           if(num>=temp->info)
           {
                prev=temp;
                temp=temp->right;
           }
           else
           {
                prev=temp;
                temp=temp->left;
           }
        }
        if(num>=prev->info)
            prev->right=p;
        else
            prev->left=p;
    }
    void preorder(node *temp)
    {
      if(temp!=NULL)
      {
          cout<<" "<<temp->info;
          preorder(temp->left);
          preorder(temp->right);
      }
    }
    void display()
    {
      if(root==NULL)
      {
          cout<<"empty\n";
          return;
      }
      preorder(root);
   }
};

int main()
{
  tree tr;
  int ch;
  while(1)
  {
    cout<<"1.put 2.print 3.exit\n";
    cin>>ch;
    switch(ch)
    {
      case 1:
         tr.insert();
         break;
      case 2:
         tr.display();
         break;
      case 3:exit(0);
    }
  }
  return 0;
}
