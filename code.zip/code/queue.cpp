#include<iostream>
#include<cstdlib>
using namespace std;
struct node{
    int info;
    struct node *next;
};
class queue{
        node *rear=NULL;
        node *front=NULL;
    public:
        void enqueue()
        {
            int data;
            node *temp = new node;
            cout<<"Enter ";
            cin>>data;
            temp->info = data;
            temp->next = NULL;
            if(front == NULL){
                front = temp;
            }else{
                rear->next = temp;
            }
            rear = temp;
        }
        void dequeue(){
             node *temp = new node;
             if(front == NULL){
                 cout<<"empty\n";
             }else{
                 temp = front;
                 front = front->next;
                 delete temp;
             }
       }
       void display(){
            node *p = new node;
            p = front;
            if(front == NULL){
                cout<<"empty\n";
           }else{
                while(p!=NULL){
                    cout<<p->info<<" ";
                    p = p->next;
               }
           }
         }
};
int main(){
    queue q;
    int ch;
    while(1){
        cout<<"\n1.insert 2.delete 3.print 4.exit\n";
        cin>>ch;
        switch(ch){
            case 1:
                q.enqueue();
                break;
            case 2:
                q.dequeue();
                break;
            case 3:
                q.display();
                break;
            case 4:
                exit(0);
                break;
        }
    }
    return 0;
}
